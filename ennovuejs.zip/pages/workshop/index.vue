<template>
  <section>
    <h1>I am the workshop index - subpage</h1>
  </section>
</template>

<script>


export default {
    name: 'Workshop',
    layout: 'subpages', // name of your new layout
    components: {
        
    }
};
</script>

<style scoped>
 
</style>