<template>
    <h1>I am the contact - subpage</h1>
</template>

<script>


export default {
    name: 'Workshop',
    layout: 'subpages', // name of your new layout
    components: {
        
    }
};
</script>